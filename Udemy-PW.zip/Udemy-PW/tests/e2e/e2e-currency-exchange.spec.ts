import {test, expect} from '@playwright/test';


test.describe('Currency exchange', () => {
  test('should exchange currency', async ({page}) => {
    await page.goto('/currency-exchange');
    await page.fill('input[name="amount"]', '100');
    await page.click('text=Exchange');
    await expect(page.locator('text=100')).toHaveText('100');
  });
});