import{ test, expect } from '@playwright/test';

test.describe('New Payment', () => {
  test('should be able to create a new payment', async ({ page }) => {
    await page.goto('http://localhost:3000');
    await page.click('text=New Payment');
    await page.fill('input[name="description"]', 'New Payment');
    await page.fill('input[name="amount"]', '100');
    await page.click('text=Create Payment');
    await page.waitForSelector('text=Payment created');
  });
});