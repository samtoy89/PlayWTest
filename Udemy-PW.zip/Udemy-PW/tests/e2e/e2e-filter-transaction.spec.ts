import {test, expect} from '@playwright/test';

test.describe('Filter transaction', () => {
  test('should filter transaction by type', async ({page}) => {
    await page.goto('/transactions');
    await page.click('text=Type');
    await page.click('text=Select');
    await page.click('text=Deposit');
    await page.click('text=Apply');
    await expect(page.locator('text=Deposit')).toHaveText('Deposit');
  });

  test('should filter transaction by amount', async ({page}) => {
    await page.goto('/transactions');
    await page.fill('input[name="amount"]', '100');
    await page.click('text=Apply');
    await expect(page.locator('text=100')).toHaveText('100');
  });
});