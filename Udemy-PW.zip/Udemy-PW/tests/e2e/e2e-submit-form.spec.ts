import{ test, expect } from '@playwright/test';
import { HomePage } from '../../page-objects/HomePage';
import { FeedbackPage } from '../../page-objects/FeedbackPage';

test.describe('Feedback form', () => {
  let homePage: HomePage;
  let feedbackPage: FeedbackPage;

  test.beforeEach(async ({ page }) => {
    // await page.goto('http://zero.webappsecurity.com/index.html');
    // await page.click('#feedback'); 
    homePage = new HomePage(page);
    feedbackPage = new FeedbackPage(page);

    await homePage.visit();
    await homePage.clickFeedbackLink();
  });

  // Reset Feedback Form
    test('Reset Feedback Form', async ({ page }) => {
        // await page.fill('#name', 'Some Name');
        // await page.fill('#email', 'Some Email@email.com');
        // await page.fill('#subject', 'Some subject');
        // await page.fill('#comment', 'Some nice omment about the application');
        // await page.click("input[name='clear']");

        // const nameInput = await page.locator('#name');
        // const commentInput = await page.locator('#comment');
        // await expect(nameInput).toBeEmpty();
        // await expect(commentInput).toBeEmpty();
        await feedbackPage.submitFeedback('Some Name', 'Some Email', 'Some Subject', 'Some Comment');
        await feedbackPage.resetForm();
        await feedbackPage.assertReset();

    });
    // Submit Feedback Form
    test('Submit Feedback Form', async ({ page }) => {
        // await page.fill('#name', 'Some Name');
        // await page.fill('#email', 'Some email@email.com');
        // await page.fill('#subject', 'Some subject');
        // await page.fill('#comment', 'Some nice comment about the application');
        // await page.click("input[type='submit']");
        // await page.waitForSelector('#feedback-title');
        await feedbackPage.submitFeedback('Some Name', 'Some Email', 'Some Subject', 'Some Comment');
        await feedbackPage.submitForm();
        await feedbackPage.feedbackFormSent();

    });
});