import { test, expect } from '@playwright/test';

test.describe('Visual tests', () => {   
    test('Full Page snapshot', async ({ page }) => {
        await page.goto('https://www.example.com');
        expect(await page.screenshot()).toMatchSnapshot('homepage.png');
    });
});

test('single test', async ({ page }) => {   
    await page.goto('https://www.example.com');
    const pageElement = await page.$('h1');
    expect(await page.screenshot()).toMatchSnapshot('page-title.png');
});


