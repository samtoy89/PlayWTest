import{ test, expect, request } from '@playwright/test';

test.describe.parallel('API tests', () => { 
    const baseUrl = 'https://reqres.in/api';
  test('Simple API Test - Assert Response Status', async ({ request }) => {
    // Test logic
    const response = await request.get(`${baseUrl}/users/2`);
    expect(response.status()).toBe(200);

    const responseBody = JSON.parse(await response.body());
  });

  test('API test 2- Assert Invalid Endpoint', async ({ request }) => {
    // Test logic
    const response = await request.get(`${baseUrl}/users/non-existing-endpoint`);
    expect(response.status()).toBe(404);
  });

  test('Get Request -  Get User Details', async ({ request }) => {
    // Test logic
    const response = await request.get(`${baseUrl}/users/1`);
    const responseBody = JSON.parse(await response.text());

    expect(response.status()).toBe(200);
    expect(responseBody.data.id).toBe(1);
  });

    test('Post Request - Create User', async ({ request }) => {
        // Test logic
        const response = await request.post(`${baseUrl}/users`, {
        data: {
            name: 'John Doe',
            job: 'QA Engineer',
        },
        });
    
        const responseBody = JSON.parse(await response.text());
        expect(response.status()).toBe(201);
        expect(responseBody.name).toBe('John Doe');
        expect(responseBody.job).toBe('QA Engineer');
    });

    test('POST Request - Login User', async ({ request }) => {
        // Test logic
        const response = await request.post(`${baseUrl}/login`, {
        data: {
            email: 'eve.holt@reqres.in',
            password: 'cityslicka', 
        },
        });
        const responseBody = JSON.parse(await response.text());
        expect(response.status()).toBe(200);
        expect(responseBody.token).toBeTruthy();
    });

    test('Post Request - Login Failed', async ({ request }) => {
        // Test logic
        const response = await request.post(`${baseUrl}/login`, {
        data: {
            email: 'eve.holt@reqres.in',
        },
        });
        const responseBody = JSON.parse(await response.text());
        expect(response.status()).toBe(400);
        expect(responseBody.error).toBe('Missing password');
    });

    test('PUT REquest - Update User', async ({ request }) => {
        // Test logic
        const response = await request.put(`${baseUrl}/users/2`, {
        data: {
            name: 'John Doe',
            job: 'QA Engineer',
        },
        });
        const responseBody = JSON.parse(await response.text());

        expect(response.status()).toBe(200);
        expect(responseBody.name).toBe('John Doe');
        expect(responseBody.job).toBe('QA Engineer');
    });

    test('Delete Request - Delete User', async ({ request }) => {
        // Test logic
        const response = await request.delete(`${baseUrl}/users/2`);
        expect(response.status()).toBe(204);
    });
});