import { test, expect } from '@playwright/test';
import browserName from '@playwright/test';

test.describe('Tips and Tick Section', () => {
    test('TestInfo Objects', async ({ page }, testInfo) => {
        await page.goto('https://www.example.com');
        //console.log(testInfo.expectedStatus);
    });

    test('Test Skip Browser', async ({ page }) => {
        //test.skip(browserName === 'chrome', 'Feature not supported in chrome browser');
        await page.goto('https://www.example.com');
    });
});