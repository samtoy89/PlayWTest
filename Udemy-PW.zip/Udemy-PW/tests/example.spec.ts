import { test, expect } from '@playwright/test';
import { loadHomepage, AssertTitle } from '../helpers';

test('Simple basic test', async ({ page }) => {
  await page.goto('https://www.example.com/');
  const pageTitle = await page.locator('h1');
  await expect(pageTitle).toContainText('Example Domain');
})

test('Clicking on Elements', async ({ page }) => {
  await page.goto('http://zero.webappsecurity.com/index.html');
  await page.click('#signin_button');
  await page.click('text=Sign in');

  const errorMessage = await page.locator('.alert-error');
  await expect(errorMessage).toHaveText('Login and/or password are wrong.');
})

test('Interacting with input fields', async ({ page }) => {
  await page.goto('http://zero.webappsecurity.com/index.html');
  await page.click('#signin_button');
  await page.fill('#user_login', 'username');
  await page.fill('#user_password', 'password');
  await page.click('input[type="submit"]');
//   await page.click('#input{type="submit"}');
})

test('Assertions', async ({ page }) => {
  await page.goto('https://example.com');
  await expect(page).toHaveURL('https://example.com/');
  await expect(page).toHaveTitle('Example Domain');

    const element = await page.locator('h1');
    await expect(element).toBeVisible();
    await expect(element).toContainText('Example Domain');
    await expect(element).toHaveCount(1);

    const nonExistentElement = await page.locator('h5');
    await expect(nonExistentElement).not.toBeVisible();
})

test.only('Custom Helpers', async ({ page }) => {
    await loadHomepage(page);
    await AssertTitle(page);
})  
// test('Simple basic test', async ({ page }) => {  