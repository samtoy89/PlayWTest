import { expect, Locator, Page } from "@playwright/test";

export class FeedbackPage {
    readonly page: Page
    readonly nameInput: Locator
    readonly emailInput: Locator
    readonly subjectInput: Locator
    readonly commentInput: Locator
    readonly submitButton: Locator
    readonly successMessage: Locator
    readonly feedbackTitle: Locator
    readonly clearButton: Locator

    constructor(page: Page) {
        this.page = page
        this.nameInput = page.locator('#name')
        this.emailInput = page.locator('#email')
        this.subjectInput = page.locator('#subject')
        this.commentInput = page.locator('#comment')
        this.feedbackTitle = page.locator('#feedback-title')
        this.clearButton = page.locator('input[type="reset"]')
        this.feedbackTitle = page.locator('#feedback-title')
    }

    async visit() {
        await this.page.goto('http://zero.webappsecurity.com/feedback.html')
    }

    async submitFeedback(name: string, email: string, subject: string, comment: string) {
        await this.nameInput.fill(name)
        await this.emailInput.fill(email)
        await this.subjectInput.fill(subject)
        await this.commentInput.fill(comment)
        await this.submitButton.click()
    }

    async getSuccessMessage() {
        return await this.successMessage.innerText()
    }

    async resetForm() {
        await this.clearButton.click()
    }

    async submitForm() {    
        await this.submitButton.click()
    }

    async assertReset() {
        expect(await this.nameInput.inputValue()).toBe('')
        expect(await this.emailInput.inputValue()).toBe('')
        expect(await this.subjectInput.inputValue()).toBe('')
        expect(await this.commentInput.inputValue()).toBe('')
    }

    async feedbackFormSent() {
        await expect(this.feedbackTitle).toBeVisible()
    }
}