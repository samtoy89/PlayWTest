import { expect, Locator, Page } from "@playwright/test";

export class Navbar {
    readonly page: Page
    readonly accountactivity: Locator
    readonly accountSummary: Locator
    readonly transferFunds: Locator
    readonly paybills: Locator
    readonly moneyMap: Locator
    readonly onlineStatements: Locator

    constructor(page: Page) {
        this.page = page
        this.accountactivity = page.locator('text=Account Activity')
        this.accountSummary = page.locator('text=Account Summary')
        this.transferFunds = page.locator('text=Transfer Funds')
        this.paybills = page.locator('text=Pay Bills')
        this.moneyMap = page.locator('text=My Money Map')
        this.onlineStatements = page.locator('text=Online Statements')
    }

    async clickAccountActivity() {
        await this.accountactivity.click()
    }

    async clickAccountSummary() {
        await this.accountSummary.click()
    }

    async clickTransferFunds() {
        await this.transferFunds.click()
    }

    async clickPayBills() {
        await this.paybills.click()
    }

    async clickMoneyMap() {
        await this.moneyMap.click()
    }

    async clickOnlineStatements() {
        await this.onlineStatements.click()
    }   
}