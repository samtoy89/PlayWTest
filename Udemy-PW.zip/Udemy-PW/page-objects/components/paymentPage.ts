import { expect, Locator, Page } from "@playwright/test";

export class PaymentPage {
  private readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async createNewPayment(description: string, amount: string) {
    await this.page.click('text=New Payment');
    await this.page.fill('input[name="description"]', description);
    await this.page.fill('input[name="amount"]', amount);
    await this.page.click('text=Create Payment');
    await this.page.waitForSelector('text=Payment created');
  }

  async getPaymentDescription(): Promise<string> {
    return this.page.locator('text=Payment created').innerText();
  }
}