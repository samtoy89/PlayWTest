import { expect, Locator, Page } from "@playwright/test";   

export class HomePage {
    [x: string]: any;
    readonly page: Page
    readonly signInButton: Locator
    readonly accountSummaryTab: Locator
    readonly searchBox: Locator
    readonly linkFeedback: Locator

    constructor(page: Page) {
        this.page = page
        this.signInButton = page.locator('#signin_button')
        this.accountSummaryTab = page.locator('#account_summary_tab')
        this.searchBox = page.locator('#searchTerm')
        this.linkFeedback = page.locator('#Feedback')
    }

    async visit() {
        await this.page.goto('http://zero.webappsecurity.com/index.html')
    }

    async clickSignInButton() {
        await this.signInButton.click()
    }

    async clickFeedbackLink() { 
        await this.linkFeedback.click()
    }

    async verifyAccountSummaryTab() {
        await expect(this.accountSummaryTab).toHaveText('Account Summary')
    }

    async searchFor(phrase: string) {
        await this.searchBox.fill(phrase)
        await this.page.keyboard.press('Enter')
    }
}