export async function loadHomepage(page) {
    await page.goto('https://www.example.com/');
}

export async function AssertTitle(page) {
    await page.waitForSelector('h1');
}